To use the image background removal API, follow these steps:

Register at https://rapidapi.com/micaelbh/api/remove-background-image-api

Get your api key, which appears in the end points.
Change the remove.js file in the first line, putting your api key.
Ready! You can now use the image background removal application.