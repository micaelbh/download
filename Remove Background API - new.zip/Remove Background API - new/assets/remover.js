
var api_key = 'YOUR AP KEY HERE'; //CHANGE THIS VALUE TO YOUR API KEY - AVAILABLE IN - https://rapidapi.com/micaelbh/api/remove-background-image-api

const input = document.getElementById("selectAvatar");
const avatar = document.getElementById("avatar");


const convertBase64 = (file) => {
    return new Promise((resolve, reject) => {
        const fileReader = new FileReader();
        fileReader.readAsDataURL(file);

        fileReader.onload = () => {
            resolve(fileReader.result);
        };

        fileReader.onerror = (error) => {
            reject(error);
        };
    });
};

const uploadImage = async (event) => {
    const file = event.target.files[0];
    const base64 = await convertBase64(file);
    base_array = base64.split(',');
    alert(base_array[1]);
    avatar.src = base64;
    //
    $("#result_image").html('<img src="assets/loader.svg">');

    //integration API Remove Background Here
  

        const settings = {
        async: true,
        crossDomain: true,
        // url: 'https://remove-background-image-api.p.rapidapi.com/base64',
        url:  'https://remove-background-image-api.p.rapidapi.com/base64',
        method: 'POST',
        headers: {
        'x-rapidapi-key': api_key,
        'x-rapidapi-host': 'remove-background-image-api.p.rapidapi.com',
        'Content-Type': 'application/json'
    },
        processData: false,
        data: '{\r\n    "img_base64_string": "'+base_array[1]+'"\r\n}'
    };

    $.ajax(settings).done(function (response) {
        console.log(response);
        
        $("#result_image").html("<img src='data:image/png;base64,"+response['str_base_64_img']+"' style='width: 600px'> <br><br> <a href='data:image/png;base64,"+ response['str_base_64_img'] +"' download='image_bg_removed'>  <button type='button'>Download</button> </a>");

        
    });

    
};

input.addEventListener("change", (e) => {
    uploadImage(e);
});
